import InfograficoPage from './components/InfograficoPage'
import './App.css'

function App() {
  return <InfograficoPage />
}

export default App
